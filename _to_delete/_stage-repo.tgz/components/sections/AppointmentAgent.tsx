'use client';

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { ArrowUpRight } from 'lucide-react';

/**
 * Appointment agent — Christina, live in the page.
 *
 * The demo is served from this site (public/appointment-demo/index.html, exposed
 * at the clean path /appointment-demo by a rewrite in next.config.mjs) so the
 * iframe is same-origin and the home page never depends on a second domain.
 * It is a copy of realtime.html in MattymBaylor/gms-voice-demo — when the agent's
 * page changes there, re-copy it here.
 *
 * ?embed=1 strips the demo's own header, footer and hero down to the bare card and
 * makes it post its height to us as { gmsVoiceDemoHeight: <px> }.
 *
 * allow="microphone" is mandatory. Without it the card renders, the button works,
 * and the agent never hears a word — with no error message anywhere.
 */
const SRC = '/appointment-demo?embed=1';
const MIN_HEIGHT = 720;

export function AppointmentAgent() {
  const frameRef = useRef<HTMLIFrameElement>(null);
  const [height, setHeight] = useState(MIN_HEIGHT);

  useEffect(() => {
    function onMessage(event: MessageEvent) {
      // Only trust the frame we rendered — not any other window on the page.
      if (!frameRef.current || event.source !== frameRef.current.contentWindow) return;
      const next = (event.data as { gmsVoiceDemoHeight?: unknown } | null)?.gmsVoiceDemoHeight;
      if (typeof next !== 'number' || !Number.isFinite(next)) return;
      setHeight(Math.max(MIN_HEIGHT, Math.ceil(next)));
    }

    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, []);

  return (
    <section
      id="appointment-agent"
      className="section"
      aria-labelledby="appointment-agent-heading"
    >
      <div className="container-wide">
        <div className="mb-14 mx-auto max-w-2xl text-center">
          <p className="eyebrow">Live demo</p>
          <h2
            id="appointment-agent-heading"
            className="mt-3 text-h1 font-semibold text-ink"
          >
            Talk to the Agent Yourself
          </h2>
          <p className="mt-4 text-lead text-ink-muted">
            Christina confirms online appointments. She&rsquo;s answering right now &mdash;
            a live agent, not a recording. Push back on her, move the date, tell her you
            never booked it, and listen to what she does with that.
          </p>
        </div>

        <div className="relative mx-auto w-full max-w-[560px]">
          <iframe
            ref={frameRef}
            src={SRC}
            title="Live AI appointment agent"
            allow="microphone"
            loading="lazy"
            className="block w-full border-0 bg-transparent"
            style={{ height, colorScheme: 'dark' }}
          />
        </div>

        <div className="mx-auto mt-10 max-w-2xl text-center">
          <p className="text-sm leading-relaxed text-ink-muted">
            The brain &mdash; the prompt, the objection policy, the handoff rules &mdash;
            lives in the orchestration layer, not the vendor. Already on Retell, Vapi,
            Bland or LiveKit? We build into it. Not yet? We recommend one and you keep the
            account. The voice is a config value, not a rebuild. In production this gets
            real telephony, a dedicated number, recording, transcripts and post-call
            analysis.
          </p>
          <p className="mt-4">
            <Link
              href="/appointment-demo"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-accent transition-colors hover:text-white"
            >
              Open full screen
              <ArrowUpRight size={13} aria-hidden="true" />
            </Link>
          </p>
        </div>
      </div>
    </section>
  );
}
